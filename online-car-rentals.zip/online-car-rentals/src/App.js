import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import DashboardPage from "./Components/dashboard/dashboard";
import LoginPage from "./Components/forms/loginPage";
import RegistrationPage from "./Components/forms/signupPage";

function App() {
  return (
    <div className="app-container">
      {/* Enables routing functionality in the app */}
      <BrowserRouter>
        {/* Define the route configuration */}
        <Routes>
          {/* Define individual routes */}

          {/* login page route */}
          <Route path="/" element={<LoginPage />} />
          {/* signup page route */}
          <Route path="/signupPage" element={<RegistrationPage />} />
          {/* dashboard page route */}
          <Route path="/dashboard" element={<DashboardPage />}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
