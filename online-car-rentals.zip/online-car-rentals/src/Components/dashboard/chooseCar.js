import React, { useState, useEffect } from "react";
import "./dashboard.css";
import axios from "axios";
import BookingForm from "./bookingdetails";

const ChooseCarForm = ({ userId }) => {
  //State variables
  const [carData, setCarData] = React.useState([]);
  const isCalledRef = React.useRef(false);
  const condition = true;
  const [car, setCar] = useState({});

  useEffect(() => {
    if (condition && !isCalledRef.current) {
      isCalledRef.current = true;
      // Fetch car data from the server
      axios
        .get("http://localhost:8080/api/Cars/all")
        .then((res) => {
          setCarData(res.data);
        })
        .catch((err) => {
          console.error(err);
        });
    }
  });

  const handleSubmit = (car, e) => {
    e.preventDefault();
    // Adding validation and submission logic here
    // Set the selected car as the chosen car
    setCar(car);
  };

  return (
    // render if carId is not null
    car?.carId ? (
      <BookingForm userId={userId} car={car} />
    ) : (
      <div className="form-container-d">
        <div className="form-content">
          <h2>Choose Your Car</h2>
          <div>
            <table border="2">
              <thead>
                <tr>
                  <th>Car Id</th>
                  <th>Car Company</th>
                  <th>Car Type</th>
                  <th>Rent</th>
                  <th>Parking Name</th>
                  <th>Select</th>
                </tr>
              </thead>
              <tbody>
                {carData.map((car) => (
                  <tr key={car.carId}>
                    <td>{car.carId}</td>
                    <td>{car.carCompany}</td>
                    <td>{car.type}</td>
                    <td>{car.rent}</td>
                    <td>{car.parkingNo.parkingName}</td>
                    <td>
                      <button onClick={(e) => handleSubmit(car, e)}>
                        Select
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    )
  );
};

export default ChooseCarForm;
