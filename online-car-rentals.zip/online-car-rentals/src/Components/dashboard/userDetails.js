import React, { useState, useEffect } from "react";
import "./dashboard.css";
import axios from "axios";

const UserDetails = ({ userId }) => {
  //State variables
  const [userData, setUserData] = useState({});
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editedUserData, setEditedUserData] = useState({});

  useEffect(() => {
    // Fetch user data from the server based on the userId
    axios
      .get(`http://localhost:8080/api/User/userId/${userId}`, {
        headers: {
          "Content-Type": "application/json;charset=UTF-8",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((res) => {
        setUserData(res.data);
      })
      .catch((err) => {
        console.error(err);
      });
  }, [userId]);

  const handleEditModalOpen = () => {
    // Set the editedUserData state to the current user data
    setEditedUserData(userData);
    //Open the edit modal
    setEditModalOpen(true);
  };

  const handleEditModalClose = () => {
    // Close the edit modal
    setEditModalOpen(false);
  };

  const handleInputChange = (e) => {
    // Update the editedUserData state when input values change
    const { name, value } = e.target;
    setEditedUserData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  // Handle form submission
  const handleEditSubmit = () => {
    // User Name validation
    if (!editedUserData.name) {
      alert("Name is required");
      return;
    }

    //Phone Number validation
    if (!editedUserData.phoneNumber) {
      alert("Phone Number is required");
      return;
    } else if (!/^\d{10}$/.test(editedUserData.phoneNumber)) {
      alert("Phone number should be 10 digits");
      return;
    }

    // Send a PUT request to update the user data on the server
    axios
      .put(`http://localhost:8080/api/User/update/${userId}`, editedUserData, {
        headers: {
          "Content-Type": "application/json;charset=UTF-8",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((res) => {
        setUserData(res.data);
        setEditModalOpen(false);
      })
      .catch((err) => {
        console.error(err);
      });
  };

  return (
    <>
      <div className="form-container-d">
        <div className="form-content">
          <h2>User Profile</h2>
          <div className="user-details">
            <div className="user-label">
              Name : <u>{userData.name}</u>
            </div>
            <div className="user-label">
              Email : <u>{userData.email}</u>
            </div>
            <div className="user-label">
              Phone number : <u>{userData.phoneNumber}</u>
            </div>
          </div>
          <button className="edit-button" onClick={handleEditModalOpen}>
            Edit User Details
          </button>
        </div>
      </div>
      {editModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <h2>Edit User Details</h2>
            <div className="edit-form">
              <div className="input-group">
                <label>Name:</label>
                <input
                  type="text"
                  name="name"
                  value={editedUserData.name || ""}
                  onChange={handleInputChange}
                />
              </div>
              <div className="input-group">
                <label>Phone Number:</label>
                <input
                  type="text"
                  name="phoneNumber"
                  value={editedUserData.phoneNumber || ""}
                  onChange={handleInputChange}
                />
              </div>
              <div className="modal-buttons">
                <button onClick={handleEditSubmit}>Save</button>
                <button onClick={handleEditModalClose}>Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default UserDetails;
