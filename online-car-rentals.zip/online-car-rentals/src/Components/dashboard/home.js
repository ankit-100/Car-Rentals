import React from "react";
import "./dashboard.css";

const HomePage = ({ userId }) => {
  return (
    <div className="form-container-d">
      <div className="form-content">
        <h2>Welcome to Wanderdrive</h2>
        <h4>Embrace Adventure, Rent with Wanderdrive</h4>
        <p>
          Your one-stop portal for affordable, reliable and hassle free car
          rentals
        </p>
        <h3>
          <u>Guidelines:</u>
        </h3>
        <ul className="home-list">
          <li>
            Click on the <b>Choose Car</b> tab on top to select your car
            <ul>
              <li>
                <b>
                  <i>Select</i>
                </b>{" "}
                the car you prefer to rent
              </li>
              <li>
                You will be redirected to the <b>Booking page</b>
              </li>
              <li>
                Provide your <i>Driving License Number</i>,<i>Booking dates</i>{" "}
                and <i>Payment method</i> to Book
              </li>
            </ul>
          </li>
          <li>
            Click on the <b>Transaction</b> tab on top to see bookings
          </li>
          <li>
            Click on the <b>User</b> tab on top to see user details and update
            them
          </li>
          <li>
            Click on the <b>Help</b> tab for any customer support
          </li>
        </ul>
        <h3>
          <u>Discount & Tax:</u>
        </h3>
        <ul>
          <li>
            Flat <b>3%</b> discount on rent amount above 3000
          </li>
          <li>GST of 5% will be levied on total cost post discount</li>
        </ul>
      </div>
    </div>
  );
};

export default HomePage;
