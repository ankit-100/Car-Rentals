import React from "react";
import './dashboard.css';

const Help = () =>{

    return(
        <div className="form-container-d">
            <div className="form-content">
                <h2>Welcome to Wanderdrive Support</h2>
                <h3 className="help-list">Emergency Contacts :</h3>
                <ul>
                    <li>Customer Care
                        <ul>
                            <li>abc@xyz.com</li>
                            <li>1800-263-225</li>
                        </ul>
                    </li>
                    <li>Mechanic
                    <ul>
                            <li>abc@xyz.com</li>
                            <li>1800-263-225</li>
                        </ul>
                    </li>
                </ul>
                <h3 className="help-list">Terms & Conditions :</h3>
                <ul>
                    <li>We provide well-maintained cars, No need of worry.</li>
                    <li>In case of breakdown, alternative will be provided on spot.</li>
                    <li>Our jurisdiction is only inside Kolkata, not outside.</li>
                    <li>If you move outside Kolkata,you will receive a warning call.</li>
                    <li>All payments are to be taken offline during pickup of car.</li>
                    <li>You must return the car within the stipulated time frame, otherwise late fine will be levied</li>
                    <li>The cars have strong gps system in-built, so we will track you.</li>
                </ul>
            </div>
            
        </div>
        
    );
};

export default Help;