import React, { useState } from "react";
import "../forms/forms.css";
import axios from "axios";
import Transaction from "./transaction";

const BookingForm = ({ userId, car }) => {
  // State variables
  const [licenseNumber, setLicenseNumber] = useState("");
  const [paymentMode, setPaymentMode] = useState("");
  const [pickupDate, setPickupDate] = useState("");
  const [returnDate, setReturnDate] = useState("");
  const [errors, setErrors] = useState({});
  const [txnData, setTxnData] = useState("");

  // Event handler for license number input change
  const handleLicenseNumberChange = (e) => {
    setLicenseNumber(e.target.value);
  };

  // Event handler for payment input change
  const handlePaymentModeChange = (e) => {
    setPaymentMode(e.target.value);
  };

  // Event handler for pickup date input change
  const handlePickupDateChange = (e) => {
    setPickupDate(e.target.value);
  };

  // Event handler for return date input change
  const handleReturnDateChange = (e) => {
    setReturnDate(e.target.value);
  };

  // Form validation
  const validateForm = () => {
    let isValid = true;
    const errors = {};

    //License Number validation
    if (
      !/^([A-Z]{2})(\d{2}|\d{3})[a-zA-Z]{0,1}(\d{4})(\d{7})$/.test(
        licenseNumber
      )
    ) {
      errors.licenseNumber = "Invalid Driving License Number";
      isValid = false;
    }

    //Pickup date and return date validation
    if (pickupDate >= returnDate) {
      errors.returnDate =
        "Return date must not be less or equal to pickup date";
      isValid = false;
    }

    setErrors(errors);
    return isValid;
  };

  // Submit form data
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (validateForm()) {
        // Add your validation and submission logic here

        // Fetch user data
        const data = await axios.get(
          `http://localhost:8080/api/User/userId/${userId}`,
          {
            headers: {
              "Content-Type": "application/json;charset=UTF-8",
              "Access-Control-Allow-Origin": "*",
            },
          }
        );
        let userData;
        if (data.status === 200) {
          userData = data.data;
        } else {
          throw new Error("Something went wrong");
        }

        // Submit transaction data
        const txnData = await axios.post(
          `http://localhost:8080/api/Transaction/insert`,
          {
            pickupDate,
            returnDate,
            dlNo: licenseNumber,
            modeOfPayment: paymentMode,
            cars: car,
            userId: userData,
          },
          {
            "Content-Type": "application/json;charset=UTF-8",
            "Access-Control-Allow-Origin": "*",
          }
        );
        if (txnData.status === 200) {
          alert("Booking Successful");
          setTxnData(txnData.data);
        } else {
          alert("Booking Failed");
        }
      }
    } catch (error) {
      alert("Booking Failed");
    }
  };

  return txnData ? (
    <Transaction userId={txnData.userId.userId} />
  ) : (
    <div className="form-container-d">
      <div className="form-content">
        <h2>Booking Form</h2>
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label htmlFor="car-company">Car Company : </label>
            {car.carCompany}
          </div>
          <div className="input-group">
            <label htmlFor="car-type">Car Type : </label>
            {car.type}
          </div>
          <div className="input-group">
            <label htmlFor="rent">Rent :</label>
            {car.rent}
          </div>
          <div className="input-group">
            <label htmlFor="parking-name">Parking Name : </label>
            {car.parkingNo.parkingName}
          </div>
          <div className="input-group">
            <label htmlFor="license-number">License Number : </label>
            <input
              type="text"
              id="license-number"
              value={licenseNumber}
              onChange={handleLicenseNumberChange}
              placeholder="Enter Driving License Number"
              required
              className={errors.licenseNumber ? "error" : ""}
            />
            {errors.licenseNumber && (
              <span className="error-message">{errors.licenseNumber}</span>
            )}
          </div>
          <div className="input-group">
            <label htmlFor="pickup-date">Pickup Date :</label>
            <input
              type="date"
              id="pickup-date"
              min="2023-06-07"
              value={pickupDate}
              onChange={handlePickupDateChange}
              placeholder="Select Pickup Date"
              required
            />
          </div>
          <div className="input-group">
            <label htmlFor="return-date">Return Date :</label>
            <input
              type="date"
              id="return-date"
              min="2023-06-08"
              value={returnDate}
              onChange={handleReturnDateChange}
              required
              className={errors.returnDate ? "error" : ""}
            />
            {errors.returnDate && (
              <span className="error-message">{errors.returnDate}</span>
            )}
          </div>
          <div className="input-group">
            <label htmlFor="payment-mode">Payment Mode :</label>
            <select
              id="payment-mode"
              value={paymentMode}
              onChange={handlePaymentModeChange}
              required
            >
              <option value="">Select Payment Mode</option>
              <option value="Card">Card</option>
              <option value="Cash">Cash</option>
              <option value="Upi">Upi</option>
            </select>
          </div>
          <button type="submit">Book Now</button>
        </form>
      </div>
    </div>
  );
};

export default BookingForm;
