import React, { useState, useEffect } from "react";
import "./dashboard.css";
import { useLocation, useNavigate } from "react-router-dom";
import Transaction from "./transaction";
import UserDetails from "./userDetails";
import Help from "./help";
import HomePage from "./home";
import ChooseCarForm from "./chooseCar";

const DashboardPage = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const userId = searchParams.get("userId");

  const navigate = useNavigate();

  useEffect(() => {
    // Check if a valid user ID is present, otherwise redirect to login
    if (!userId || userId === "") {
      navigate("/");
    }
  }, [userId, navigate]);

  // State variables
  const [chooseCar, setChooseCar] = useState(false);
  const [transaction, setTransaction] = useState(false);
  const [userDetails, setUserDetails] = useState(false);
  const [help, setHelp] = useState(false);

  //handles the logout part
  const handleLogout = () => {
    navigate("/", { replace: true });
  };

  // Handles onclick functions to respective tabs
  const handleClickLink = (e) => {
    e.preventDefault();
    const link = e.target.getAttribute("href");
    switch (link) {
      case "/dashboard/chooseCar":
        // Toggle the chooseCar state and reset other state
        setChooseCar((prevState) => !prevState);
        setTransaction(false);
        setUserDetails(false);
        setHelp(false);
        break;
      case "/dashboard/transaction":
        // Toggle the transaction state and reset other states
        setChooseCar(false);
        setTransaction((prevState) => !prevState);
        setUserDetails(false);
        setHelp(false);
        break;
      case "/dashboard/userDetails":
        // Toggle the userDetails state and reset other states
        setChooseCar(false);
        setTransaction(false);
        setUserDetails((prevState) => !prevState);
        setHelp(false);
        break;
      case "/dashboard/help":
        // Toggle the help state and reset other states
        setChooseCar(false);
        setTransaction(false);
        setUserDetails(false);
        setHelp((prevState) => !prevState);
        break;
      default:
        // Reset all states
        setChooseCar(false);
        setTransaction(false);
        setUserDetails(false);
        setHelp(false);
        break;
    }
  };

  const renderTable = () => {
    // Render the appropriate component based on the active state
    if (chooseCar) {
      return <ChooseCarForm userId={userId} />;
    } else if (transaction) {
      return <Transaction userId={userId} />;
    } else if (userDetails) {
      return <UserDetails userId={userId} />;
    } else if (help) {
      return <Help />;
    } else {
      return <HomePage userId={userId} />;
    }
  };

  return (
    <div className="dashboard-container">
      <div className="dashboard-heading">WanderDrive</div>
      <nav>
        <ul className="navbar">
          <li>
            <a href={`/dashboard?userId=${userId}`}>Home</a>
          </li>
          <li>
            <a href="/dashboard/chooseCar" onClick={handleClickLink}>
              Choose Car
            </a>
          </li>
          <li>
            <a href="/dashboard/transaction" onClick={handleClickLink}>
              Bookings
            </a>
          </li>
          <li>
            <a href="/dashboard/userDetails" onClick={handleClickLink}>
              User
            </a>
          </li>
          <li>
            <a href="/dashboard/help" onClick={handleClickLink}>
              Help
            </a>
          </li>
          <li>
            <a href=" " onClick={handleLogout}>
              Logout
            </a>
          </li>
        </ul>
      </nav>
      <div className="dashboard-content">{renderTable()}</div>
    </div>
  );
};

export default DashboardPage;
