import React, { useEffect } from "react";
import "../forms/forms.css";
import axios from "axios";

const Transaction = ({ userId }) => {
  // State variables
  const [transactionData, setTransactionData] = React.useState([]);
  const isCalledRef = React.useRef(false);
  const condition = true;

  useEffect(() => {
    // This effect will be called when the component mounts and when the condition is true
    if (condition && !isCalledRef.current) {
      isCalledRef.current = true;
      axios
        .get("http://localhost:8080/api/Transaction/all")
        .then((res) => {
          setTransactionData(res.data);
        })
        .catch((err) => {
          console.error(err);
        });
    }
  }, [condition]); // Add condition as a dependency to the effect

  return (
    <div className="form-container-d">
      <div className="form-content-transaction">
        <h2>Bookings</h2>
        <form>
          <div>
            <table border="2">
              <thead>
                <tr>
                  <th>Transaction Id</th>
                  <th>Car Id</th>
                  <th>Car Company</th>
                  <th>Car Type</th>
                  <th>Parking name</th>
                  <th>Driving License</th>
                  <th>Pickup date</th>
                  <th>Return date</th>
                  <th>Rent Cost</th>
                  <th>Discount</th>
                  <th>Tax</th>
                  <th>Total Cost</th>
                </tr>
              </thead>
              <tbody>
                {transactionData.map((transaction) => (
                  <tr key={transaction.transactionId}>
                    <td>{transaction.transactionId}</td>
                    <td>{transaction.cars.carId}</td>
                    <td>{transaction.cars.carCompany}</td>
                    <td>{transaction.cars.type}</td>
                    <td>{transaction.cars.parkingNo.parkingName}</td>
                    <td>{transaction.dlNo}</td>
                    <td>{transaction.pickupDate}</td>
                    <td>{transaction.returnDate}</td>
                    <td>
                      {transaction.cost -
                        transaction.tax +
                        transaction.discount}
                    </td>
                    <td>{transaction.discount}</td>
                    <td>{transaction.tax}</td>
                    <td>
                      <b>{Math.round(transaction.cost)}</b>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Transaction;
