import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
import "./forms.css";

const LoginPage = () => {
  // State variables
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [userId, setUserId] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to the dashboard if a userId is set
    if (userId !== "") {
      navigate(`/dashboard?userId=${userId}`);
    }
  }, [userId, navigate]);

  // Event handler for email input change
  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  // Event handler for password input change
  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  // Event handler for toggling password visibility
  const handleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  // Form validation
  const validateForm = () => {
    let isValid = true;
    const errors = {};

    // Email validation
    if (!email) {
      errors.email = "Email is required";
      isValid = false;
    } else if (!/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/.test(email)) {
      errors.email = "Email is invalid";
      isValid = false;
    }

    // Password validation
    if (!password) {
      errors.password = "Password is required";
      isValid = false;
    } else if (!/(?=.*[A-Z])(?=.*\d)(?=.*\W).{6,}/.test(password)) {
      errors.password =
        "Password must be of minimum 6 characters having Uppercase, Lowercase, Number and Symbols(@+-*/).";
      isValid = false;
    }

    setErrors(errors);
    return isValid;
  };

  // Form submit handler
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (validateForm()) {
      try {
        const response = await axios.get(`/api/User/email/${email}`);
        if (!response.data) {
          setUserId("");
          alert("User is not signed up. Please sign up first.");
        } else {
          if (response.data.password === password) {
            // Go to user dashboard from here using useEffect
            alert("Successfully logged in");
            setUserId(response.data.userId);
          } else {
            setUserId("");
            alert("Password does not match.");
          }
        }
      } catch (error) {
        setUserId("");
        alert("Cannot access Database.");
      }
    }
  };

  return (
    <div className="form-container">
      <div className="form-content">
        <h2>Welcome to WanderDrive!</h2>
        <h4>Embrace Adventure, Rent with Wanderdrive</h4>
        <div className="login-heading">
          Please <b>Login</b> to continue
        </div>

        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label>Email :</label>
            <input
              type="email"
              id="userEmail"
              placeholder="Enter Email"
              onChange={handleEmailChange}
              value={email}
              className={errors.email ? "error" : ""}
            />
            {errors.email && (
              <span className="error-message">{errors.email}</span>
            )}
          </div>

          <div className="input-group">
            <label>Password :</label>
            <div className="password-input">
              <input
                type={showPassword ? "text" : "password"}
                id="password"
                value={password}
                placeholder="Enter Password"
                onChange={handlePasswordChange}
                className={errors.password ? "error" : ""}
              />
              <i
                className={`eye-icon ${showPassword ? "show" : ""}`}
                onClick={handleShowPassword}
              >
                <FontAwesomeIcon icon={showPassword ? faEyeSlash : faEye} />
              </i>
            </div>
            {errors.password && (
              <span className="error-message">{errors.password}</span>
            )}
          </div>
          <button type="submit">Login</button>
        </form>
        <div className="redirect">
          Don't have an account? <Link to="/signupPage">Register</Link>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
