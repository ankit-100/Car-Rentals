import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
import "./forms.css";

// Set the default base URL for Axios
axios.defaults.baseURL = "http://localhost:8080";

const RegistrationPage = () => {
  // State variables
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmpassword, setConfirmPassword] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  // Redirect to login page after successful registration
  const handleRegistration = (data) => {
    navigate("/");
  };

  // Prepare user object to be submitted
  const handleUserChange = () => {
    return {
      name: name,
      email: email,
      password: password,
      phoneNumber: phoneNumber,
    };
  };

  // Event handler for name input change
  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  // Event handler for email input change
  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  // Event handler for password input change
  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  // Event handler for confirm password input change
  const handleConfirmPasswordChange = (e) => {
    setConfirmPassword(e.target.value);
  };

  // Event handler for phone number input change
  const handlePhoneNumberChange = (e) => {
    setPhoneNumber(e.target.value);
  };

  // Event handler for toggling password visibility
  const handleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  // Event handler for toggling confirm password visibility
  const handleShowConfirmPassword = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  // Form validation
  const validateForm = () => {
    let isValid = true;
    const errors = {};

    // Name validation
    if (!name) {
      errors.name = "Name is required";
      isValid = false;
    }

    // Email validation
    if (!email) {
      errors.email = "Email is required";
      isValid = false;
    } else if (!/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/.test(email)) {
      errors.email = "Email is invalid";
      isValid = false;
    }

    // Password validation
    if (!password) {
      errors.password = "Password is required";
      isValid = false;
    } else if (!/(?=.*[A-Z])(?=.*\d)(?=.*\W).{6,}/.test(password)) {
      errors.password = "Password is invalid.";
      isValid = false;
    }

    //Confirm Password Validation
    if (!confirmpassword) {
      errors.confirmpassword = "Password is required";
      isValid = false;
    } else if (password !== confirmpassword) {
      errors.confirmpassword = "Password is not matched";
      isValid = false;
    }

    // Phone number validation
    if (!phoneNumber) {
      errors.phoneNumber = "Phone number is required";
      isValid = false;
    } else if (!/^\d{10}$/.test(phoneNumber)) {
      errors.phoneNumber = "Phone number should be 10 digits";
      isValid = false;
    }

    setErrors(errors);
    return isValid;
  };

  // Submit form data
  const handleSubmit = (e) => {
    e.preventDefault();

    if (validateForm()) {
      // Add your registration logic here
      const user = handleUserChange();

      let conf = {
        headers: {
          "Content-Type": "application/json;charset=UTF-8",
          "Access-Control-Allow-Origin": "*",
        },
      };

      // Send registration request to the server
      axios
        .post(
          "http://localhost:8080/api/User/insert",
          {
            name: user.name,
            email: user.email,
            password: user.password,
            phoneNumber: user.phoneNumber,
          },
          conf
        )

        .then((response) => {
          alert("Sucessfully Registred !");
          handleRegistration(response.data);
        })

        .catch((error) => {
          if (error.response && error.response.status === 404) {
            alert("User registration failed.");
          } else {
            alert("User Already Exist Please Login");
          }
        });
    }
  };

  return (
    <div className="form-container">
      <div className="form-content">
        <h2>Create an Account...</h2>
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label>Name :</label>
            <input
              type="text"
              value={name}
              placeholder="Enter Name"
              onChange={handleNameChange}
              className={errors.name ? "error" : ""}
            />
            {errors.name && (
              <span className="error-message">{errors.name}</span>
            )}
          </div>
          <div className="input-group">
            <label>Email :</label>
            <input
              type="email"
              value={email}
              placeholder="Enter Email"
              onChange={handleEmailChange}
              className={errors.email ? "error" : ""}
            />
            {errors.email && (
              <span className="error-message">{errors.email}</span>
            )}
          </div>

          <div className="input-group">
            <label>Password :</label>
            <div className="password-input">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                placeholder="Enter Password"
                onChange={handlePasswordChange}
                className={errors.password ? "error" : ""}
              />
              <i
                className={`eye-icon ${showPassword ? "show" : ""}`}
                onClick={handleShowPassword}
              >
                <FontAwesomeIcon icon={showPassword ? faEyeSlash : faEye} />
              </i>
            </div>
            {errors.password && (
              <span className="error-message">{errors.password}</span>
            )}
          </div>

          <div className="input-group">
            <label>Confirm Password :</label>
            <div className="password-input">
              <input
                type={showConfirmPassword ? "text" : "password"}
                value={confirmpassword}
                placeholder="Confirm Password"
                onChange={handleConfirmPasswordChange}
                className={errors.confirmpassword ? "error" : ""}
              />
              <i
                className={`eye-icon ${showConfirmPassword ? "show" : ""}`}
                onClick={handleShowConfirmPassword}
              >
                <FontAwesomeIcon
                  icon={showConfirmPassword ? faEyeSlash : faEye}
                />
              </i>
            </div>
            {errors.confirmpassword && (
              <span className="error-message">{errors.confirmpassword}</span>
            )}
          </div>

          <div className="input-group">
            <label>Phone Number :</label>
            <input
              type="tel"
              value={phoneNumber}
              placeholder="Enter Phone Number"
              onChange={handlePhoneNumberChange}
              className={errors.phoneNumber ? "error" : ""}
            />
            {errors.phoneNumber && (
              <span className="error-message">{errors.phoneNumber}</span>
            )}
          </div>
          <button type="submit">Register</button>
        </form>
        <div className="redirect">
          Already have an account?
          <Link to="/">Login</Link>
        </div>
        <div>
          <br />
          Input Pattern:
          <br />
          <ul>
            <li>Password must be at least 6 characters long.</li>
            <li>
              Password must have at least one digit(0-9),special character and
              Uppercase(A-Z).
            </li>
            <li>Phone Number must be of 10 digits only.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default RegistrationPage;
